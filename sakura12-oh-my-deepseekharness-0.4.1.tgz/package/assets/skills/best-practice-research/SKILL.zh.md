---
name: best-practice-research
description: 有边界的最佳实践调研封装——官方/上游证据优先，产出带来源的推荐与明确交接
when-to-use: 任务依赖当前外部最佳实践、版本感知指引、标准、官方推荐或上游行为（针对已选定的技术）。不用于纯仓库本地问题（用 explore/research）或依赖选型/对比决策。
---

# best-practice-research（最佳实践调研）

当任务依赖当前外部最佳实践、版本感知指引、标准、官方推荐或上游行为时使用本技能。这是一个工作流封装：它路由证据收集与综合；它不是新的调研权威，也不取代通用 `research` 通道。

## 目的

产出带来源、可复用的最佳实践答案或交接，把当前外部证据与仓库本地事实、依赖选型决策分开。作为规划前调查，这是常规的第一道调研封装：先收集官方/上游证据，再交给规划通道（`ralplan` / `plan`）或调用方作为规划输入。不要把本技能包装成最终架构组件或 validator 门禁的调研循环。

## 默认终态

本技能默认终态且只读。它收集证据、产出带来源的推荐与交接，然后停止。在本技能下不写/改文件、不建/改 commit、不跑变更命令、不以任何方式修改仓库状态——即使问题有明显的实现含义。需要实现时，停止并交接而非继续：规划点名 `ralplan` / `plan`，执行点名 `autopilot` / `team` / `omd-agent-executor`，只有当用户显式切换到该工作流时才继续。

## 何时激活

- 用户询问最佳实践、推荐做法、当前指引、官方推荐、标准或版本感知的外部行为。
- `ralplan`、`deep-interview`、`team` 或其他工作流在规划/执行之前需要当前外部证据才能做对。
- 任务涉及已选定的技术，需要权威用法指引、迁移说明、API 行为、生命周期规则或当前安全指引。

## 何时不激活

- 答案完全在仓库本地；代码库事实用 `omd-agent-explore` / `research`。
- 主要问题是是否采用、替换、升级或对比依赖——这是 `omd-agent-dependency-expert` 的专职车道（候选对比、漏洞、许可证、迁移路径），直接路由给它。
- 用户只需要按已落地的需求做实现；直接执行，或需要协调的并行工作时用 `team`。
- 任务可由稳定的本地项目约定回答，无需当前外部检索。

## 专员路由

1. brownfield 事实先用 `omd-agent-explore`（经 `subagent`，硬路由用 `omd_delegate`）：当前代码用法、本地约束、版本、配置与集成点。
2. 官方/上游文档、release notes、标准、迁移指南、有源可溯的示例、已选定技术的当前最佳实践证据，用 `omd-agent-document-specialist`。直接检索时本通道内用 `web_search` / `read_page` 也可以。
3. 采用/升级/替换/对比决策路由给 `omd-agent-dependency-expert`（专职车道）；本技能只提供来源质量规则与其检索结论的输入，不替它做选型裁决。
4. 带着显式证据、不确定性与任何实现交接约束返回调用方。

## 来源质量规则

- 优先官方文档、上游源码、release notes、changelog、标准与维护者指引。
- 实质性论断必须附来源 URL。
- 当前最佳实践论断必须标注日期/版本上下文。
- 第三方摘要标注为 supplemental；在官方/上游来源之前不用它们。
- 标记过期、冲突、无文档或版本不匹配的证据。
- 不过度抓取：收集能支撑决策的最小证据集。

## 流程

1. 问题分类：概念性最佳实践、实现指引、迁移/版本指引、标准/合规指引，或本地+外部混合指引。
2. 当本地用法或约束影响答案时，用 `omd-agent-explore` / `grep` / `glob` / `read` 收集仓库本地事实。
3. 当当前或版本感知的实践影响正确性时，用 `omd-agent-document-specialist` / `web_search` / `read_page` 收集外部证据。
4. 综合为简洁答案：来源质量、版本/日期上下文、注意事项、实现或规划交接。
5. 答案对调用方足够落地时停止；否则报告确切的阻塞点或所需的专员交接。

## 输出契约

```md
## Best-Practice Research: <question>

### Direct Recommendation
<可执行的指引或决策支持>

### Evidence Used
- Official/upstream: <source URL> — <它确立了什么>
- Supplemental, if any: <source URL> — <为何是次要的>

### Version / Date Context
<版本、日期、发布通道或未知项>

### Repo-Local Context
<来自 explore 的事实，或 "not needed">

### Boundaries / Non-goals
<本调研不定夺的部分>

### Handoff
<规划/执行/测试含义；点名下一工作流——规划用 `ralplan` / `plan`，执行用 `autopilot` / `team` / `omd-agent-executor`——并注明除非用户显式切换工作流，本技能到此为止>
```

## 停止规则

- 带来源的推荐对调用方可复用后即停止。
- 任务演变为依赖对比、宏观架构或实现时，停止并向上路由。
- 剩余工作只是润色措辞而不改变推荐时，不再继续调研。
- 本技能永不实现。交付推荐与交接后停止；不修改仓库文件或状态。只有当用户显式切换到交接中点名的规划或实现工作流时才继续。

## 状态契约

本技能**不持模式状态**，不在 `.omd/state/` 下创建任何内容。带来源的答案以最后一条消息交付；值得长期保留的最佳实践事实写 `mcp__omd-state__notepad_write_priority` / `notepad_write_working`。
